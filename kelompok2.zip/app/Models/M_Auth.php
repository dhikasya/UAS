<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Auth extends Model
{

    protected $table = "tb_user";
    protected $primaryKey = 'id_user';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['id_user', 'nama_user', 'nim', 'email', 'password'];

    public function login($email, $password)
    {
        if ($email === false) {
            return $this->findAll();
        }
        return $this->asArray()->where(['email' => $email, password_verify($password, 'password')])->first();
    }

    public function pass($email)
    {
        return $this->db->table('tb_user')->where(['email' => $email])->get()->getResultArray();
    }

    public function getUser($id_user = false)
    {
        if ($id_user === false) {
            return $this->findAll();
        }
        return $this->where(['id_user' => $id_user])->first();
    }
}
