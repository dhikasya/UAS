<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Provinsi extends Model
{
    protected $table = "tb_provinsi";
    protected $primaryKey = 'id_provinsi';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['id_provinsi', 'provinsi', 'created_at'];

    public function getCategory($id_provinsi = false)
    {
        if ($id_provinsi === false) {
            return $this->findAll();
        }
        return $this->where(['id_provinsi' => $id_provinsi])->first();
    }

    public function getByID()
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('tb_provinsi'); // Produces: SELECT * FROM mytable
        $query   = $builder->orderBy('provinsi', 'ASC');
        $query = $builder->get();

        return $query->getResult('array');
    }

    public function countCategory()
    {
        $db      = \Config\Database::connect();
        $query = $db->query('SELECT * FROM tb_kategoriproduk');

        return $query->getNumRows();
    }
}
