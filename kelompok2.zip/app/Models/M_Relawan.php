<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Relawan extends Model
{
    protected $table = "tb_relawan";
    protected $primaryKey = 'id_relawan';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['id_relawan', 'nama', 'alamat', 'provinsi', 'email', 'nohp', 'keahlian', 'created_at'];

    public function getRelawan($id_relawan = false)
    {
        if ($id_relawan === false) {
            return $this->findAll();
        }
        return $this->where(['id_relawan' => $id_relawan])->first();
    }

    public function getByID()
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('tb_relawan'); // Produces: SELECT * FROM mytable
        $query   = $builder->orderBy('id_relawan', 'DESC');
        $query = $builder->get();

        return $query->getResult('array');
    }

    public function countCategory()
    {
        $db      = \Config\Database::connect();
        $query = $db->query('SELECT * FROM tb_kategoriproduk');

        return $query->getNumRows();
    }
}
