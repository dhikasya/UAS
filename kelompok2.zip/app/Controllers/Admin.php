<?php

namespace App\Controllers;

use App\Models\M_Provinsi;
use App\Models\M_Relawan;

class Admin extends BaseController
{
    public function __construct()
    {
        $this->M_Provinsi = new M_Provinsi();
        $this->M_Relawan = new M_Relawan();
    }

    public function index()
    {
        session();
        $data = [
            'title' => 'Admin',
            'id_relawan' => $this->M_Relawan->getByID(),
        ];
        return view('admin/list', $data);
    }

    public function Tambah()
    {
        session();
        $data = [
            'title' => 'Admin',
            'provinsi' => $this->M_Provinsi->getByID(),
            'validation' => \Config\Services::validation()
        ];
        return view('admin/tambah', $data);
    }

    public function hapusData($id_relawan)
    {
        $data['id_relawan'] = $this->M_Relawan->where('id_relawan', $id_relawan)->delete();
        session()->setFlashdata('delete', 'Data Data Relawan Berhasil Dihapus !');
        return redirect()->to('/Admin');
    }

    public function Edit($id_relawan)
    {
        session();
        $data = [
            'title' => 'Admin',
            'id_relawan' => $this->M_Relawan->getRelawan($id_relawan),
            'provinsi' => $this->M_Provinsi->getByID(),
            'validation' => \Config\Services::validation()
        ];

        return view('admin/edit', $data);
    }

    public function Cetak($id_relawan)
    {
        $data = [
            'title' => 'Data Relawan',
            'id_relawan' => $this->M_Relawan->getRelawan($id_relawan)
        ];
        return view('admin/print', $data);
    }

    public function tambahData()
    {
        if (!$this->validate([
            'provinsi' => [
                'rules' => 'required|is_unique[tb_relawan.provinsi]',
                'errors' => [
                    'required' => 'provinsi harus terisi',
                    'is_unique' => 'provinsi sudah terdaftar'
                ]
            ],
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom nama harus terisi'
                ]
            ],
            'alamat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom alamat harus terisi'
                ]
            ],
            'email' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom email harus terisi'
                ]
            ],
            'nohp' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom no.hp harus terisi'
                ]
            ],
            'keahlian' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom keahlian harus terisi'
                ]
            ],

        ])) {

            $validation = \Config\Services::validation();
            return redirect()->to('/Admin/tambah')->withInput()->with('validation', $validation);
        }

        $this->M_Relawan->save([
            'provinsi'    => $this->request->getPost('provinsi'),
            'nama'    => $this->request->getPost('nama'),
            'alamat'    => $this->request->getPost('alamat'),
            'email'    => $this->request->getPost('email'),
            'nohp'    => $this->request->getPost('nohp'),
            'keahlian'    => $this->request->getPost('keahlian'),
        ]);

        session()->setFlashdata('tambah', 'Data Relawan Berhasil Ditambahkan!');
        return redirect()->to('/Admin');
    }

    public function updateData($id_relawan)
    {
        if (!$this->validate([
            'provinsi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'provinsi harus terisi',
                ]
            ],
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom nama harus terisi'
                ]
            ],
            'alamat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom alamat harus terisi'
                ]
            ],
            'email' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom email harus terisi'
                ]
            ],
            'nohp' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom no.hp harus terisi'
                ]
            ],
            'keahlian' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'kolom keahlian harus terisi'
                ]
            ],

        ])) {
            $validation = \Config\Services::validation();
            return redirect()->to('/Admin/Edit/' . $this->request->getPost('id_relawan'))->withInput();
        }

        $this->M_Relawan->save([
            'id_relawan' => $id_relawan,
            'provinsi'    => $this->request->getPost('provinsi'),
            'nama'    => $this->request->getPost('nama'),
            'alamat'    => $this->request->getPost('alamat'),
            'nohp'    => $this->request->getPost('nohp'),
            'email'    => $this->request->getPost('email'),
            'keahlian'    => $this->request->getPost('keahlian'),
        ]);

        session()->setFlashdata('update', 'Data Relawan Berhasil Diubah !');
        return redirect()->to('/Admin');
    }

    public function tambahProv()
    {
        session();
        $data = [
            'title' => 'Admin',
            'provinsi' => $this->M_Provinsi->getByID(),
            'validation' => \Config\Services::validation()
        ];
        return view('admin/tambahprov', $data);
    }

    public function saveProv()
    {
        if (!$this->validate([
            'provinsi' => [
                'rules' => 'required|is_unique[tb_pasien.provinsi]',
                'errors' => [
                    'required' => 'provinsi harus terisi',
                    'is_unique' => 'provinsi sudah terdaftar'
                ]
            ],
        ])) {
            $validation = \Config\Services::validation();
            return redirect()->to('/Admin/tambahProv')->withInput()->with('validation', $validation);
        }

        $this->M_Provinsi->save([
            'provinsi'    => $this->request->getPost('provinsi'),
        ]);

        session()->setFlashdata('tambah', 'Data Provinsi Berhasil Ditambahkan !');
        return redirect()->to('/Admin/tambahProv');
    }

    public function hapusProv($id_provinsi)
    {
        $data['id_provinsi'] = $this->M_Provinsi->where('id_provinsi', $id_provinsi)->delete();
        session()->setFlashdata('delete', 'Data Data Provinsi Berhasil Dihapus !');
        return redirect()->to('/Admin/tambahProv');
    }
}
