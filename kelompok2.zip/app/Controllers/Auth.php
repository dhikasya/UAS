<?php

namespace App\Controllers;

use App\Models\M_Auth;

class Auth extends BaseController
{
    public function __construct()
    {
        $this->M_Auth = new M_Auth();
    }

    public function register()
    {

        $data = [
            'title' => 'Register',
            'id_user' => $this->M_Auth->getUser(),
            'validation' => \Config\Services::validation(),
        ];

        return view('admin/register', $data);
    }

    public function save_register()
    {
        if (!$this->validate([
            'nama_user' => [
                'rules' => 'required|is_unique[tb_user.nama_user]',
                'errors' => [
                    'required' => 'nama user harus terisi',
                    'is_unique' => 'nama user sudah terdaftar'
                ]
            ],
            'nim' => [
                'rules' => 'required|is_unique[tb_user.nim]',
                'errors' => [
                    'required' => 'nim harus terisi',
                    'is_unique' => 'nim sudah terdaftar',
                ]
            ],
            'email' => [
                'rules' => 'required|is_unique[tb_user.email]|valid_email',
                'errors' => [
                    'required' => 'email harus terisi',
                    'is_unique' => 'email sudah terdaftar',
                    'valid_email' => 'bukan email'
                ]
            ],
            'password' => [
                'rules' => 'required|is_unique[tb_user.password]',
                'errors' => [
                    'required' => 'password harus terisi',
                    'is_unique' => 'password sudah terdaftar'
                ]
            ]

        ])) {
            // dd($this->request->getPost());
            $validation = \Config\Services::validation();
            return redirect()->to('/Auth/register')->withInput();
        }
        // $passhas = 'password';
        // $passhas = $this->request->getPost($passhas)->password_hash('password', PASSWORD_DEFAULT);
        $pass =  password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);
        $this->M_Auth->save([
            'nama_user'    => $this->request->getPost('nama_user'),
            'nim'    => $this->request->getPost('nim'),
            'email'    => $this->request->getPost('email'),
            'password'    => $pass
        ]);

        session()->setFlashdata('tambah', 'Regsitrasi Berhasil !');
        return redirect()->to('/Auth/register');
    }

    public function login()
    {
        // session_destroy();
        session();
        $data = [
            'title' => 'Login',
            'validation' => \Config\Services::validation(),
        ];

        return view('auth/login', $data);
    }

    public function hapus($id_user)
    {
        $data['id_user'] = $this->M_Auth->where('id_user', $id_user)->delete();
        session()->setFlashdata('delete', 'Data Data User Berhasil Dihapus !');
        return redirect()->to('/Auth/register');
    }

    public function cek_login()
    {
        if ($this->validate([
            'email' => [
                'rules' => 'required|valid_email',
                'errors' => [
                    'required' => 'email harus terisi',
                    'valid_email' => 'bukan email'
                ]
            ],
            'password' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'password harus terisi',
                ]
            ],
        ])) {
            //valid
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');
            // $userModel = $this->M_Auth = new M_Auth();
            // $cek = $userModel->asArray()->where('email', $email)->first();
            $cek = $this->M_Auth->login($email, $password);
            if ($cek) {
                if (password_verify($password, $cek['password'])) {

                    //jika sama
                    session()->set('log', true);
                    session()->set('nama_user', $cek['nama_user']);
                    session()->set('email', $cek['email']);
                    session()->set('nim', $cek['nim']);

                    return redirect()->to('/Admin');
                }
            } else {
                //tidak sama
                $validation = \Config\Services::validation();
                return redirect()->to('/Auth/login')->withInput();
            }
        } else {
            //tidak valid
            $validation = \Config\Services::validation();
            return redirect()->to('/Auth/login')->withInput();
        }
    }

    public function logout()
    {
        session()->remove('log');
        session()->remove('nama_user');
        session()->remove('email');
        session()->remove('nim');
        session()->remove('password');
        session()->setFlashdata('update', 'logut berhasil');
        return redirect()->to('/auth/login');
    }
}
