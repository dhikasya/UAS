<!DOCTYPE html>
<html lang="en">

<?= $this->extend('admin/template') ?>

<?= $this->section('content') ?>

<div class="limiter">
    <div class="container mt-5">
        <form action="/Auth/cek_login" method="POST" class="login100-form validate-form p-b-33 p-t-5">
            <div class="wrap" style="margin: 250px; padding: 50px;">
                <h2 class="text-center mb-4">Form Login</h2>
                <div class="mb-3" data-validate="Enter username">
                    <input class="form-control <?= ($validation->hasError('email')) ? 'is-invalid' : ''; ?>" type="email" name="email" placeholder="Email" autocomplete="off">
                    <div class="invalid-feedback form-text">
                        <?= $validation->getError('email'); ?>
                    </div>
                </div>

                <div class="mb-3" data-validate="Enter password">
                    <input class="form-control <?= ($validation->hasError('password')) ? 'is-invalid' : ''; ?>" type="password" name="password" placeholder="Password">
                    <div class="invalid-feedback form-text">
                        <?= $validation->getError('password'); ?>
                    </div>
                </div>

                <div class="container text-center">
                    <button class="btn btn-primary rounded-pill" type="submit">
                        Login
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection(); ?>