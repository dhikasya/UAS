<?= $this->extend('admin/template') ?>

<?= $this->section('content') ?>

<div id="print-area-1" class="print-area">
    <div class="container mt-5">
        <div class="row text-center">
            <h2>Data Relawan Covid19 wilayah <?= $id_relawan['provinsi'] ?></h2>
            <h5>Per <?= date('d  M  Y h:i:s'); ?></h5>
            <h5><?= session()->get('nama_user') ?>/<?= session()->get('nim') ?></h5>
        </div>
        <table class="table mt-5">
            <thead>
                <tr class="text-center" style="border-width: 2px;">
                    <th scope="col" style="border-width: 2px;">Nama Lengkap</th>
                    <th scope="col" style="border-width: 2px;">Alamat Rumah</th>
                    <th scope="col" style="border-width: 2px;">Provinsi</th>
                    <th scope="col" style="border-width: 2px;">Email</th>
                    <th scope="col" style="border-width: 2px;">No. Hp</th>
                    <th scope="col" style="border-width: 2px;">Keahlian</th>
                </tr>
            </thead>
            <tbody>
                <tr class="text-center" style="border-width: 2px;">
                    <td style="border-width: 2px;"><?= $id_relawan['nama'] ?></td>
                    <td style="border-width: 2px;"><?= $id_relawan['alamat'] ?></td>
                    <td style="border-width: 2px;"><?= $id_relawan['provinsi'] ?></td>
                    <td style="border-width: 2px;"><?= $id_relawan['email'] ?></td>
                    <td style="border-width: 2px;"><?= $id_relawan['nohp'] ?></td>
                    <td style="border-width: 2px;"><?= $id_relawan['keahlian'] ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <!-- <script>
        window.print();
    </script> -->
</div>

<?= $this->endSection() ?>