<?= $this->extend('admin/template') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <div class="row">
        <h2>Ubah Data Pemantauan Covid19</h2>
    </div>
    <div class="row mt-5">
        <form action="/Admin/updateData/<?= $id_relawan['id_relawan']; ?>" method="POST">
            <input type="hidden" name="id_relawan" value="<?= esc($id_relawan['id_relawan']); ?>">
            <div class="row">
                <div class="mb-3">
                    <label class="form-label">Provinsi</label>
                    <select class="form-control <?= ($validation->hasError('provinsi')) ? 'is-invalid' : ''; ?>" aria-label="Default select example" name="provinsi">
                        <?php
                        $a = $id_relawan['provinsi'];
                        if ($a = $id_relawan['provinsi']) {
                            echo $b = $id_relawan['provinsi'];
                            echo $c = '';
                        } else {
                            echo $b = 'Pilih Provinsi';
                            echo $c = 'disabled';
                        }
                        ?>
                        <option selected <?= $c; ?> value="<?= $a; ?>"><?= $b; ?></option>
                        <?php if (!empty($provinsi) && is_array($provinsi)) : ?>
                            <?php foreach ($provinsi as $row) : ?>
                                <option value="<?= $row['provinsi'] ?>"><?= $row['provinsi'] ?></option>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <option value="">Provinsi belum tersedia</option>
                        <?php endif ?>
                    </select>
                    <div class="invalid-feedback form-text">
                        <?= $validation->getError('provinsi'); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control <?= ($validation->hasError('nama')) ? 'is-invalid' : ''; ?>" value="<?= esc($id_relawan['nama']) ?>" placeholder="Ketikan nama lengkap.">
                        <div class="invalid-feedback form-text">
                            <?= $validation->getError('nama'); ?>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="mb-3">
                        <label class="form-label">Alamat Rumah</label>
                        <input type="text" name="alamat" class="form-control <?= ($validation->hasError('alamat')) ? 'is-invalid' : ''; ?>" value="<?= esc($id_relawan['alamat']) ?>" placeholder="Ketikan alamat rumah.">
                        <div class="invalid-feedback form-text">
                            <?= $validation->getError('alamat'); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control <?= ($validation->hasError('email')) ? 'is-invalid' : ''; ?>" value="<?= esc($id_relawan['email']) ?>" placeholder="Ketikan email.">
                        <div class="invalid-feedback form-text">
                            <?= $validation->getError('email'); ?>
                        </div>
                    </div>
                    <div class="mt-5">
                        <a href="/Admin" type="submit" class="btn btn-secondary" style="margin-right: 10px;">Kembali</a>
                        <button type="submit" class="btn btn-primary">Ubah</button>
                    </div>
                </div>
                <div class="col">
                    <div class="mb-3">
                        <label class="form-label">No. Hp</label>
                        <input type="number" name="nohp" class="form-control <?= ($validation->hasError('nohp')) ? 'is-invalid' : ''; ?>" value="<?= esc($id_relawan['nohp']) ?>" placeholder="Ketikan No. Hp.">
                        <div class="invalid-feedback form-text">
                            <?= $validation->getError('nohp'); ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Keahlian</label>
                        <input type="text" name="keahlian" class="form-control <?= ($validation->hasError('keahlian')) ? 'is-invalid' : ''; ?>" value="<?= esc($id_relawan['keahlian']) ?>" placeholder="Ketikan keahlian.">
                        <div class="invalid-feedback form-text">
                            <?= $validation->getError('keahlian'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection(); ?>