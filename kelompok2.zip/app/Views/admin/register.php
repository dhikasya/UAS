<?= $this->extend('admin/template') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <div class="row">
        <h2>Tambah Data User Admin</h2>
    </div>
    <div class="row">
        <?php if (session()->getFlashdata('tambah')) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('tambah'); ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('update')) : ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('update'); ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('delete')) : ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('delete'); ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <form action="/Auth/save_register" method="POST">
            <label class="form-label mt-3">Nama User</label>
            <input type="text" name="nama_user" class="form-control <?= ($validation->hasError('nama_user')) ? 'is-invalid' : ''; ?>" value="<?= old('nama_user') ?>" placeholder="Ketikan nama user.">
            <div class="invalid-feedback form-text">
                <?= $validation->getError('nama_user'); ?>
            </div>
            <label class="form-label mt-3">NIM</label>
            <input type="number" name="nim" class="form-control <?= ($validation->hasError('nim')) ? 'is-invalid' : ''; ?>" value="<?= old('nim') ?>" placeholder="Ketikan NIM.">
            <div class="invalid-feedback form-text">
                <?= $validation->getError('nim'); ?>
            </div>
            <label class="form-label mt-3">Email</label>
            <input type="text" name="email" class="form-control <?= ($validation->hasError('email')) ? 'is-invalid' : ''; ?>" value="<?= old('email') ?>" placeholder="Ketikan email.">
            <div class="invalid-feedback form-text">
                <?= $validation->getError('email'); ?>
            </div>
            <label class="form-label mt-3">Password</label>
            <input type="password" name="password" class="form-control <?= ($validation->hasError('password')) ? 'is-invalid' : ''; ?>" value="<?= old('password') ?>" placeholder="Ketikan password.">
            <div class="invalid-feedback form-text">
                <?= $validation->getError('password'); ?>
            </div>
            <div class="col mt-3">
                <a href="/Admin" type="submit" class="btn btn-secondary" style="margin-right: 10px;">Kembali</a>
                <button type="submit" class="btn btn-primary">Tambah</button>
            </div>
        </form>
    </div>
    <h5 class="mt-5 mb-3">Nama User yang Terdaftar</h5>
    <div class="row">
        <div class="col-md-8">
            <ul class="list-group">
                <?php
                foreach ($id_user as $row) : ?>
                    <li class="list-group-item">
                        <a class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin menghapus data ?');" href="/Auth/hapus/<?= esc($row['id_user']); ?>" style="margin-right: 10px;">Hapus</a>
                        Nama : <?= $row['nama_user']; ?> | NIM : <?= $row['nim']; ?> | Email : <?= $row['email']; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

</div>
<?= $this->endSection(); ?>