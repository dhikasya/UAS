<?= $this->extend('admin/template') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <div class="row">
        <div class="col">
            <h2>Data Relawan Covid19</h2>
            <p style="margin-bottom: 0px;">Admin : <?= session()->get('nama_user') ?></p>
            <p style="margin-bottom: 0px;">NIM : <?= session()->get('nim') ?></p>
            <p>Universitas Pamulang</p>
        </div>
        <div class="col">
            <div class="container d-flex justify-content-end">
                <a href="/Admin/Tambah" class="btn btn-primary" style="margin-right: 10px;">Tambah Data</a>
                <a href="/Admin/tambahProv" class="btn btn-secondary" style="margin-right: 10px;">Tambah Provinsi</a>
                <a href="/Auth/register" class="btn btn-warning" style="margin-right: 10px;">Tambah User</a>
                <a class="btn btn-danger" href="/Auth/logout">Logout</a>
            </div>
        </div>
    </div>
    <div class="row">
        <?php if (session()->getFlashdata('tambah')) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('tambah'); ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('update')) : ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('update'); ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('delete')) : ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('delete'); ?>
            </div>
        <?php endif; ?>
    </div>
    <table class="table table-hover mt-5">
        <thead>
            <tr class="text-center">
                <th scope="col">No.</th>
                <th scope="col">Nama Lengkap</th>
                <th scope="col">Alamat Rumah</th>
                <th scope="col">Provinsi</th>
                <th scope="col">Email</th>
                <th scope="col">No. Hp</th>
                <th scope="col">Keahlian</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php if (!empty($id_relawan) && is_array($id_relawan)) : ?>
                <?php foreach ($id_relawan as $row) : ?>
                    <tr class="text-center">
                        <td><?= $i++; ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td><?= $row['alamat'] ?></td>
                        <td><?= $row['provinsi'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['nohp'] ?></td>
                        <td><?= $row['keahlian'] ?></td>
                        <td>
                            <a class="btn btn-success btn-sm" href="/Admin/Cetak/<?= $row['id_relawan']; ?>" target="_BLANK">Print</a>
                            <a href="/Admin/Edit/<?= $row['id_relawan']; ?>" class="btn btn-primary btn-sm">Edit</a>
                            <a href="/Admin/hapusData/<?= esc($row['id_relawan']); ?>">
                                <button onclick="return confirm('Apakah anda yakin menghapus data ?');" class="btn btn-danger btn-sm">Hapus</button>
                            </a>
                        </td>
                    <tr class="text-center">
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr class="text-center">
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                <?php endif ?>
        </tbody>
    </table>
</div>
<?= $this->endSection(); ?>