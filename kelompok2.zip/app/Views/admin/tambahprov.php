<?= $this->extend('admin/template') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <div class="row">
        <h2>Tambah Data Provinsi Covid19</h2>
    </div>
    <div class="row">
        <?php if (session()->getFlashdata('tambah')) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('tambah'); ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('update')) : ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('update'); ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('delete')) : ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?= session()->getFlashdata('delete'); ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <form action="/Admin/saveProv" method="POST">
            <label class="form-label">Nama Provinsi</label>
            <input type="text" name="provinsi" class="form-control <?= ($validation->hasError('provinsi')) ? 'is-invalid' : ''; ?>" value="<?= old('provinsi') ?>" placeholder="Ketikan nama provinsi.">
            <div class="invalid-feedback form-text">
                <?= $validation->getError('provinsi'); ?>
            </div>
            <div class="col mt-3">
                <a href="/Admin" type="submit" class="btn btn-secondary" style="margin-right: 10px;">Kembali</a>
                <button type="submit" class="btn btn-primary">Tambah</button>
            </div>
        </form>
    </div>
    <h5 class="mt-5 mb-3">Nama Provinsi yang Terdaftar</h5>
    <div class="row">
        <div class="col-md-4">
            <ul class="list-group">
                <?php
                foreach ($provinsi as $row) : ?>
                    <li class="list-group-item">
                        <a class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin menghapus data ?');" href="/Admin/hapusProv/<?= esc($row['id_provinsi']); ?>" style="margin-right: 10px;">Hapus</a>
                        <?= $row['provinsi']; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

</div>
<?= $this->endSection(); ?>